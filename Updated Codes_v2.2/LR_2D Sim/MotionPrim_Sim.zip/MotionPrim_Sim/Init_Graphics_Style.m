% Initailize plotting style 
   
   set(0,'DefaultLineLineWidth', 2) 
   set(0,'DefaultaxesLineWidth', 2) 
   set(0,'DefaultaxesFontSize', 16) 
   set(0,'DefaultTextFontSize', 16) 
   set(0,'DefaultaxesFontName', 'arial') 